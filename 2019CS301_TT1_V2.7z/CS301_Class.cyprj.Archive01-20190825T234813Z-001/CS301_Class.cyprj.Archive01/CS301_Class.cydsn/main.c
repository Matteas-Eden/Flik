/* ========================================
 * Fully working code: 
 * PWM      : 
 * Encoder  : 
 * ADC      : display millvolts of connected component
 * USB      : port displays speed and position.
 * CMD: "PW xx"
 * Copyright Univ of Auckland, 2016
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF Univ of Auckland.
 *
 * ========================================
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <project.h>
//* ========================================
#include "defines.h"
#include "vars.h"
#define ADC_READING_SIZE 300
#define LIGHT_LEVEL 500
//* ========================================
void usbPutString(char *s);
void usbPutChar(char c);
void handle_usb();
int getMax(int * readings);
// CY_ISR_PROTO(ADC_ISR); // apparently unnecessary?
//* ========================================
char rf_string[RXSTRINGSIZE];
char line[BUF_SIZE], entry[BUF_SIZE];
uint8 usbBuffer[BUF_SIZE];
int portCheck = TRUE;
volatile uint8 JALL = TRUE;
volatile char words[100];
volatile uint8 flagFinished = FALSE;
volatile uint8 cnt = 0;
volatile uint8 wordStarted = FALSE;
//* ========================================
volatile int16 result;
volatile uint8 dataReady;
struct data_main system_state;

CY_ISR(ADC_ISR){
    result = CY_GET_REG16(ADC_SAR_SAR_WRK0_PTR);
    dataReady = 1;
}

CY_ISR(interrupted)
{
    #ifdef isrRF_RX_INTERRUPT_INTERRUPT_CALLBACK
        isrRF_RX_Interrupt_InterruptCallback();
    #endif /* isrRF_RX_INTERRUPT_INTERRUPT_CALLBACK */ 

    /*  Place your Interrupt code here. */
    /* `#START isrRF_RX_Interrupt` */
    
    /* Taking in ASCII over UART */
    char c = UART_GetChar();
    
    if (c == '#'){
        cnt = 0;
        words[cnt] = c;
        cnt++;
        flagFinished = FALSE;
    }
    else if ((cnt>0) && (c != '\n')){
        words[cnt] = c;
        cnt++;
        flagFinished = FALSE;
    }
    else if (c=='\n'){
        words[cnt] = '\n';
        words[cnt+1] = '\0';
        cnt=0;
        flagFinished = TRUE;
        isrRF_RX_Disable();
    }
    
    /* Taking into raw binary data over UART */
    // UART_GetByte();
    /* `#END` */
}

int main()
{
    

// --------------------------------    
// ----- INITIALIZATIONS ----------
    int adc_readings[ADC_READING_SIZE]; // TODO make a macro
    int on_black = FALSE; 
    int i = 0;
    int max_value = 0;
    int count = 0;
    int16 newReading = 0;
    CYGlobalIntEnable;
    ADC_Init();
    ADC_Start(); // Start ADC
    ADC_IRQ_Enable(); // Enable ADC interrupts
    ADC_StartConvert(); // Start conversions
    isr_eoc_StartEx(ADC_ISR); // link interrupt for ADC
    isrRF_RX_StartEx(interrupted); // link interrupt for RF RX

// ------USB SETUP ----------------    
#ifdef USE_USB    
    USBUART_Start(0,USBUART_5V_OPERATION);
#endif        
    
    // RF_BT_SELECT_Write(0);
    // UART_Start();
    Clock_PWM_Start();
    PWM_1_Start();
    PWM_2_Start();
    
    usbPutString(displaystring);
    PWM_1_WriteCompare(0);
    PWM_2_WriteCompare(0);
    for(;;)
    {
        /* Place your application code here. */
        //handle_usb();
        if (dataReady != 0){
            dataReady = 0;
            
            // output reading
            newReading = result;
            
            // prints reading
//            if (result  <= 9) {
//                usbPutString("   ");
//            } else if (result <= 99) {
//                usbPutString("  ");
//            } else {
//                usbPutString(" ");
//            }
//            char buffer[20];
//            itoa(result,buffer,10);
//            usbPutString(buffer);
            
            i++;
            if (i == ADC_READING_SIZE) {
                i = 0;
            }
            adc_readings[i] = result;
            
            if (i == 0) {
                // get the maximum value in the array
                max_value = getMax(adc_readings);
                
                char buffer[20];
                itoa(max_value,buffer,10);
                usbPutString(buffer);
                usbPutString("   ");
                
                if (max_value > LIGHT_LEVEL) {
                    on_black = FALSE;
                    LED_Write(1);
                    PWM_1_WriteCompare(256);
                    PWM_2_WriteCompare(256);
                    //usbPutString("1 "); // light
                }
                else {
                    on_black = TRUE;
                    LED_Write(0);
                    PWM_1_WriteCompare(0);
                    PWM_2_WriteCompare(0);
                    //usbPutString("0 "); // dark
                }
            }
        }
        
        // Output received ASCII message from RF
//        if (flagFinished) {
//            while (words[i] != '\0'){
//                usbPutChar(words[i]);
//                CyDelayUs(5);
//                i++;
//            }
//            flagFinished = FALSE;
//            isrRF_RX_Enable();
//        }
        
//    count++;
//    if (count == 
//        if (count < 200) {
//            count++;
//        }
//        else {
//            
//            CONTROL_Write(1);
//            return 0;
//            // TODO: stop the wheel
//        }
    }
}
// Simple int maximum number function
int getMax(int * readings){
    int j;
    int max = readings[0];
    for (j = 1; j < ADC_READING_SIZE; j++) {
        if (readings[j] > max) {
           max = readings[j];
        }
    }
    return max;
}
//* ========================================
void usbPutString(char *s)
{
// !! Assumes that *s is a string with allocated space >=64 chars     
//  Since USB implementation retricts data packets to 64 chars, this function truncates the
//  length to 62 char (63rd char is a '!')

#ifdef USE_USB
    // Attempt to remove dependency on Putty
    if (portCheck){
        uint32 x = 0;
        while (USBUART_CDCIsReady() == 0){
            x++;
            if (x == 3000000){
                portCheck = FALSE;
            }
        };
        s[63]='\0';
        s[62]='!';
        USBUART_PutData((uint8*)s,strlen(s));
    }
#endif
}
//* ========================================
void usbPutChar(char c)
{
#ifdef USE_USB
    // Attempt to remove dependency on Putty
    if (portCheck){
        uint32 x = 0;
        while (USBUART_CDCIsReady() == 0){
            x++;
            if (x == 3000000){
                portCheck = FALSE;
            }
        };
        USBUART_PutChar(c);
    }
#endif    
}
//* ========================================
void handle_usb()
{
    // handles input at terminal, echos it back to the terminal
    // turn echo OFF, key emulation: only CR
    // entered string is made available in 'line' and 'flag_KB_string' is set
    
    static uint8 usbStarted = FALSE;
    static uint16 usbBufCount = 0;
    uint8 c; 
    

    if (!usbStarted)
    {
        if (USBUART_GetConfiguration())
        {
            USBUART_CDC_Init();
            usbStarted = TRUE;
        }
    }
    else
    {
        if (USBUART_DataIsReady() != 0)
        {  
            c = USBUART_GetChar();

            if ((c == 13) || (c == 10))
            {
//                if (usbBufCount > 0)
                {
                    entry[usbBufCount]= '\0';
                    strcpy(line,entry);
                    usbBufCount = 0;
                    flag_KB_string = 1;
                }
            }
            else 
            {
                if (((c == CHAR_BACKSP) || (c == CHAR_DEL) ) && (usbBufCount > 0) )
                    usbBufCount--;
                else
                {
                    if (usbBufCount > (BUF_SIZE-2) ) // one less else strtok triggers a crash
                    {
                       USBUART_PutChar('!');        
                    }
                    else
                        entry[usbBufCount++] = c;  
                }  
            }
        }
    }    
}


/* [] END OF FILE */

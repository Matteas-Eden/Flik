#ifndef POINT_H
#define POINT_H
    
#include <stdint.h>

typedef struct point{
    int8_t x;
    int8_t y;
} point;

#endif
#ifndef LINE_MAP_H
#define LINE_MAP_H

/* Just a wrapper for the map file they give us to make things easier */
#include "map4.h"

#endif